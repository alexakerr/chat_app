from flask import Flask, render_template
from flask_socketio import SocketIO, send, emit, join_room, leave_room
from flask_cors import CORS

app = Flask(__name__)
app.config["SECRET_KEY"] = "private_key"

socketio = SocketIO(app, cors_allowed_origins="*")

messages = []
rooms = {}

@app.route("/")
def index():
    return render_template("index.html")

@socketio.on("connect")
def handle_connect():
    print("Client has connected")
    emit("update_rooms", list(rooms.keys()), broadcast=True)

@socketio.on("disconnect")
def handle_disconnect():
    print("Client has disconnected")

@socketio.on("send_chat_message")
def handle_chat_message(data):
    username = data.get("username")
    message = data.get("message")
    output = f"<b>{username}</b>: {message}"    
    messages.append(output)
    send(output, broadcast=True)

@socketio.on("add_room")
def handle_add_room(data):
    room = data["room"]
    username = data["username"]
    if room not in rooms:
        rooms[room] = []
        join_room(room)
        rooms[room].append(username)
        emit("room_created", room, broadcast=True)
        send(f"{username} has created and entered the room {room}.", room=room)
    else:
        emit("error", f"Room {room} already exists.")

@socketio.on("join")
def handle_join(data):
    room = data["room"]
    username = data["username"]
    if room in rooms:
        join_room(room)
        rooms[room].append(username)
        send(f"{username} has joined the room {room}.", room=room)
    else:
        emit("error", f"Room {room} doesn't exist")

@socketio.on("leave")
def handle_leave(data):
    room = data["room"]
    username = data["username"]
    if room in rooms:
        leave_room(room)
        rooms[room].remove(username)
        send(f"{username} has exited {room}.", room=room)
        if not rooms[room]:
            del rooms[room]
            emit("room_deleted", room, broadcast=True)

@socketio.on("message")
def handle_message(data):
    room = data["room"]
    username = data["username"]
    message = data["message"]
    output = f"<b>{username}</b>: {message}"
    messages.append(output)
    if room in rooms:
        send(output, room=room)
    else:
        emit("error", "Enter a room to chat")

if __name__ == "__main__":
    socketio.run(app, debug=True)